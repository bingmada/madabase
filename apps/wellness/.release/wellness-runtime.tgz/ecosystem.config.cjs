module.exports = {
  apps: [
    {
      name: "madabase-wellness",
      cwd: __dirname,
      script: "./start.mjs",
      interpreter: "node",
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      max_memory_restart: "350M",
      env: {
        NODE_ENV: "production",
        HOSTNAME: "127.0.0.1",
        PORT: "3030",
      },
    },
  ],
};
