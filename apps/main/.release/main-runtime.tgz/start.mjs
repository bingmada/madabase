const major = Number(process.versions.node.split(".")[0]);
if (major !== 20) {
  console.error(`Standalone runtime requires Node 20.x; received ${process.version}.`);
  process.exit(1);
}
await import("./apps/main/server.js");
